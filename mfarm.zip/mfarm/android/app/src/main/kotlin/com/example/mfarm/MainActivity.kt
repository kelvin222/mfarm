package com.example.mfarm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
