import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFe1eaf1); //primary color of our website
const kSecondaryColor = Color(0xFF2D5A27); //sec#2D5A27ondary color
const kMaxWidth = 1232.0;
const kPadding = 20.0;
